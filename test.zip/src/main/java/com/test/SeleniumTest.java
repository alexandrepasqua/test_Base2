package com.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.By;

public class SeleniumTest {
    public static void main(String[] args) {
        // Configura o caminho do WebDriver (opcional, se estiver usando o WebDriver Manager)
        System.setProperty("webdriver.chrome.driver", "\"C:\\Users\\alexandre.pasqua\\Downloads\\Teste\\chromedriver-win32\\chromedriver.exe\"");

        // Cria uma instância do WebDriver
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("useAutomationExtension", false);
        WebDriver driver = new ChromeDriver(options);

        try {
            // Abre o navegador e acessa a URL
            driver.get("https://mantis-prova.base2.com.br/login_page.php");

            // Clique no campo username e insira o valor
            WebElement usernameField = driver.findElement(By.id("username"));
            usernameField.sendKeys("Alexandre_Pasqua");

            // Clique no botão de Entrar
            WebElement loginButton = driver.findElement(By.xpath("//input[@value='Entrar']"));
            loginButton.click();

            // Adicione mais ações conforme necessário
        } finally {
            // Feche o navegador
            driver.quit();
        }
    }
}
